import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const form = await request.formData();
  const email = String(form.get("email") || "").trim();

  if (!email || !email.includes("@")) {
    return NextResponse.json({ ok: false, message: "Valid email required." }, { status: 400 });
  }

  return NextResponse.json({
    ok: true,
    message: "Subscription captured by the CortexWire stub endpoint.",
  });
}
